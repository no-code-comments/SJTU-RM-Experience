#ifndef __VISUALSCOPE_H__
#define __VISUALSCOPE_H__

#include "stm32f4xx.h"
#include "usart.h"


typedef uint32_t  u32;
typedef uint16_t u16;
typedef uint8_t  u8;



//通过串口发送VisualScope识别的数据
//void VisualScope		(UART_HandleTypeDef *huart,int16_t CH1,int16_t CH2,int16_t CH3,int16_t CH4);



#endif
